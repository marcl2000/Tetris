#include "shape.h"
#include "coord.h"
#include <vector>
#include "cell.h"

using namespace std;

vector<Coord> Shape::getMembers(){
	vector<Coord> temp;
	return temp;
}

string Shape::getName(){
	string temp = "";
	return temp;
}

vector<Cell>& Shape::getCells(){
	vector<Cell> temp;
	return temp;
}
int Shape::getLevel(){
       return 0;
}

bool Shape::wasScored(){
	return true;
}

